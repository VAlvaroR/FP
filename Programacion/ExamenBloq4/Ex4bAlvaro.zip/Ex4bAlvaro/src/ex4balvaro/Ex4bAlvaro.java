/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex4balvaro;

import java.io.*;
import java.util.*;

/**
 *
 * @author alvaror
 */
public class Ex4bAlvaro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String ficheroParteAYB = "/home/alvaror/Escritorio/file1Ex4b.txt";
        String ficheroParteC = "/home/alvaror/Escritorio/file2Ex4b.bin";

        // PARTE A
        Set<Modulo> daw1 = new TreeSet<>();

        daw1.add(new Modulo(483, "SI", "Sistemas informáticos", (byte) 5));
        daw1.add(new Modulo(484, "BD", "Bases de Datos", (byte) 6));
        daw1.add(new Modulo(485, "PROG", "Programación", (byte) 8));
        daw1.add(new Modulo(373, "LMSGI", "Lenguajes de Marcas y Sistemas de Gestión de Información", (byte) 3));
        daw1.add(new Modulo(487, "ED", "Entornos de Desarrollo", (byte) 3));
        daw1.add(new Modulo(1709, "IPE", "Itinerario Profesional para la Empleabilidad", (byte) 3));
        daw1.add(new Modulo(1708, "SASP", "Sostenibilidad Aplicada al Sistema Productivo", (byte) 1));
        daw1.add(new Modulo(1665, "DASP", "Digitalización Aplicada al Sistema Productivo", (byte) 1));

        String[] salida = new String[daw1.size()];
        int j = 0;
        for (Modulo m : daw1) {
            System.out.println(m);
            salida[j] = m.getCodigo() + " " + m.getNombre() + " " + m.getSiglas() + " " + m.getNum_horas() + " horas";
            j++;
        }

        try {
            BufferedWriter buf = new BufferedWriter(new FileWriter(ficheroParteAYB, false));

            for (int i = 0; i < salida.length; i++) {
                String s = salida[i] + "\n";
                buf.write(s);
            }
            buf.close();
        } catch (IOException e) {
            System.out.println("Error");
        }

        // PARTE B
        String[] array1 = new String[daw1.size()];

        try {

            FileReader entrada = new FileReader(ficheroParteAYB);
            BufferedReader buf = new BufferedReader(entrada);
            String linea = "";
            int k = 0;
            while (linea != null) {
                linea = buf.readLine();
                if (linea != null) {
                    array1[k] = linea;
                    k++;
                }

            }
            buf.close();

        } catch (IOException e) {
            System.out.println("Error");
        }
        
        for (int i=0;i<array1.length;i++) {
            System.out.println(array1[i]);
        }

        // PARTE C
        Modulo[] arrayMod = new Modulo[daw1.size()];

        int cont = 0;
        for (Modulo m : daw1) {
            arrayMod[cont] = m;
            cont++;
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ficheroParteC))) {
            oos.writeObject(arrayMod);
        } catch (IOException e) {
            System.out.println("Error");
        }

        try {
            ObjectInputStream flujo2 = new ObjectInputStream(new FileInputStream(ficheroParteC));
            Modulo[] obj = (Modulo[])flujo2.readObject();
            for (int i=0;i<obj.length;i++) {
                System.out.println(obj[i]);
            }
            flujo2.close();
        } catch (Exception e) {
            System.out.println("Error");

        }
        
        // PARTE D
        Set<Modulo> daw2 = daw1;
        
        for (Modulo m : daw1) {
            System.out.println(m);
        }
        
    }

}
