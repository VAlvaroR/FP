/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex4balvaro;

import java.io.*;
import java.util.*;

/**
 *
 * @author alvaror
 */
public class Modulo implements Comparable<Modulo>, Serializable {
    private int codigo;
    private String siglas;
    private String nombre;
    private byte num_horas;

    public Modulo(int codigo, String siglas, String nombre, byte num_horas) {
        this.codigo = codigo;
        this.siglas = siglas;
        this.nombre = nombre;
        this.num_horas = num_horas;
    }

    public int getCodigo() {return codigo;}
    public void setCodigo(int codigo) {this.codigo = codigo;}

    public String getSiglas() {return siglas;}
    public void setSiglas(String siglas) {this.siglas = siglas;}

    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}

    public int getNum_horas() {return num_horas;}
    public void setNum_horas(byte num_horas) {this.num_horas = num_horas;}

    @Override
    public String toString() {
        return codigo +" "+nombre+" "+siglas+" "+num_horas+" horas";
    }
    @Override
    public int compareTo(Modulo mod) {
        if (this.codigo==mod.codigo) {
            return 0;
        }else if (this.codigo>mod.codigo) {
            return 1;
        }else if (this.codigo<mod.codigo){
            return -1;
        }else {
            return this.nombre.compareTo(mod.nombre);
        }
        


    }

    
    
}
