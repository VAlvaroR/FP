/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exament78.Empleados;
    import java.time.*;
    import java.util.*;
/**
 *
 * @author Carlos
 */
public class Empleado implements Comparable<Empleado>{
    public String nombre;
    public LocalDate fechaNac;
    public double sueldo;

    @Override
    public int compareTo(Empleado emp) {
        return this.nombre.compareTo(emp.nombre);
    }
    
    public static Comparator<Empleado> compararPorFecha= new Comparator<Empleado>(){
        @Override
        public int compare(Empleado e1, Empleado e2){
            return e1.fechaNac.compareTo(e2.fechaNac);
        }
    };

    public Empleado(String nombre, LocalDate fechaNac, double sueldo) {
        this.nombre = nombre;
        this.fechaNac = fechaNac;
        this.sueldo = sueldo;
    }
    
    @Override
    public String toString(){
        return this.nombre+" nacido el "+this.fechaNac+" con un sueldo de "+this.sueldo+"€";
    }
}
