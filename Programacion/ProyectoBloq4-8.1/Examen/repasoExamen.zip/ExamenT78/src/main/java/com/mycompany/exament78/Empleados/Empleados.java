/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.exament78.Empleados;
    import java.util.*;
    import java.time.*;
/**
 *
 * @author Carlos
 */
public class Empleados {

    public static void menu(){
        System.out.println("ELIGE UNA OPCION:\n"
                + "1. Añadir empleado.\n"
                + "2. Ordenados por nombre.\n"
                + "3, Ordenados por fecha de nacimiento.");
    }
    
    public static void annadirEmpleado(ArrayList<Empleado> empleados, Scanner teclado){
        int year, mes, dia;
        String nombre;
        System.out.println("Dame el nombre del empleado: ");
        nombre=teclado.nextLine();
        System.out.println("Dime el año: ");
        year=teclado.nextInt();
        System.out.println("Dime el mes: ");
        mes=teclado.nextInt();
        System.out.println("Dime el dia del mes: ");
        dia=teclado.nextInt();
        LocalDate fechaNac=LocalDate.of(year, mes, dia);
        System.out.println("Dime el sueldo");
        Empleado empleado=new Empleado(nombre, fechaNac, teclado.nextDouble());
        empleados.add(empleado);
    }
    
    public static void ordenadosNombre(ArrayList<Empleado> empleados){
        Collections.sort(empleados);        
        for(Empleado e: empleados){
            System.out.println(e);
        }
    }
    
    public static void ordenadosFecha(ArrayList<Empleado> empleados){
        empleados.sort(Empleado.compararPorFecha);
        for(Empleado e: empleados){
            System.out.println(e);
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        ArrayList<Empleado> empleados=new ArrayList<>();
        int op;
        do{
            menu();
            op=teclado.nextInt();
            teclado.nextLine();
            switch(op){
                case 1:
                    annadirEmpleado(empleados, teclado);
                    break;
                case 2:
                    ordenadosNombre(empleados);
                    break;
                case 3:
                    ordenadosFecha(empleados);
                    break;
            }
        }while(op!=4);
    }
    
}
