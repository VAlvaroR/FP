/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.examen78.tema8;

import java.util.*;
import java.io.*;

/**
 *
 * @author Carlos
 */
public class Archivo {
   
    public static void menu(){
        System.out.println("ELIGE TU OPCION:\n"
                + "1. Ver todas las notas.\n"//Adicion personal
                + "2. Mayor nota.\n"
                + "3. Menor nota.\n"
                + "4. Media.\n"
                + "5. Salir");
    }
    
    public static void mostrarNotas(String archivo) throws FileNotFoundException{
        FileReader file= new FileReader(archivo);
        Scanner lector=new Scanner(file);
        while(lector.hasNext()){
            System.out.println(lector.next()+" "+lector.nextDouble());
        }
        lector.close();
    }
    
    public static void mostrarMayor(String archivo) throws FileNotFoundException{
        FileReader file= new FileReader(archivo);
        Scanner lector=new Scanner(file);
        String nombre=lector.next(), temporal;
        double mayor=lector.nextDouble(), temporalNota;
        while(lector.hasNext()){
            temporal=lector.next();
            temporalNota=lector.nextDouble();
            if(temporalNota>mayor){
                mayor=temporalNota;
                nombre=temporal;
            }
        }
        System.out.println(nombre+" "+mayor);
        lector.close();
    }
    
    public static void mostrarMenor(String archivo) throws FileNotFoundException{
        FileReader file= new FileReader(archivo);
        Scanner lector=new Scanner(file);
        String nombre=lector.next(), temporal;
        double menor=lector.nextDouble(), temporalNota;
        while(lector.hasNext()){
            temporal=lector.next();
            temporalNota=lector.nextDouble();
            if(temporalNota<menor){
                menor=temporalNota;
                nombre=temporal;
            }
        }
        System.out.println(nombre+" "+menor);
        lector.close();
    }
    
    public static void mostrarMedia(String archivo) throws FileNotFoundException{
        FileReader file= new FileReader(archivo);
        Scanner lector=new Scanner(file);
        double suma=0;
        int cont=0;
        while(lector.hasNext()){
            lector.next();
            suma+=lector.nextDouble();
            cont++;
        }
        System.out.println("La media es: "+suma/cont);
        lector.close();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        try{
            Scanner teclado=new Scanner(System.in);
            String fileName="C:\\Users\\Carlos\\Documents\\NetBeansProjects\\ExamenT78\\src\\main\\java\\com\\mycompany\\examen78\\tema8\\archivo.txt";
            int op;
            do{
                menu();
                op=teclado.nextInt();
                switch(op){
                    case 1:
                        mostrarNotas(fileName);
                        break;
                    case 2:
                        mostrarMayor(fileName);
                        break;
                    case 3:
                        mostrarMenor(fileName);
                        break;
                    case 4:
                        mostrarMedia(fileName);
                        break;
                    case 5:
                        System.out.println("Saliendo del programa...");
                }
            }while(op!=5);
        }
        catch(IOException e){
            System.err.println("Error al leer el archivo"+e.getMessage());
        }
    }
    
}
