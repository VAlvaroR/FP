/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.examen78.buffers;

import java.io.*;
import java.util.*;

/**
 *
 * @author Carlos
 */
public class Buffers {

    /**
     * @param args the command line arguments
     */
    
    public static void menu(){
        System.out.println("ELIGE TU OPCION:\n"
                + "1. Ver todas las notas.\n"//Adicion personal
                + "2. Mayor nota.\n"
                + "3. Menor nota.\n"
                + "4. Media.\n"
                + "5. Salir");
    }
    
    public static void verNotas(String fichero) throws IOException{
        FileReader archivo=new FileReader(fichero);
        BufferedReader buffer=new BufferedReader(archivo);
        String linea="";
        while(linea!=null){
            linea=buffer.readLine();
            if(linea!=null){
                System.out.println(linea);
            }
            
        }
    }
    
    public static String mayorNota(String fichero) throws IOException{
        FileReader archivo=new FileReader(fichero);
        BufferedReader buffer=new BufferedReader(archivo);
        String linea=buffer.readLine();
        String[] partes=linea.split(" ");
        String nombre=partes[0], temporal;
        double mayor=Double.parseDouble(partes[1]), temporalNota;
        while((linea=buffer.readLine())!=null){
            partes=linea.split(" ");
            if(linea!=null){
                temporal=partes[0];
                temporalNota=Double.parseDouble(partes[1]);
                if(temporalNota>mayor){
                    nombre=temporal;
                    mayor=temporalNota;
                }
            }
        }
        return nombre+" "+mayor;
    }
    
    public static String menorNota(String fichero) throws IOException{
        FileReader archivo=new FileReader(fichero);
        BufferedReader buffer=new BufferedReader(archivo);
        String linea=buffer.readLine();
        String[] partes=linea.split(" ");
        String nombre=partes[0], temporal;
        double menor=Double.parseDouble(partes[1]), temporalNota;
        while((linea=buffer.readLine())!=null){
            partes=linea.split(" ");
            if(linea!=null){
                temporal=partes[0];
                temporalNota=Double.parseDouble(partes[1]);
                if(temporalNota<menor){
                    nombre=temporal;
                    menor=temporalNota;
                }
            }
        }
        return nombre+" "+menor;
    }
    
    public static String media(String fichero) throws IOException{
        FileReader archivo=new FileReader(fichero);
        BufferedReader buffer=new BufferedReader(archivo);
        String linea=buffer.readLine();
        String[] partes=linea.split(" ");
        double suma=Double.parseDouble(partes[1]);
        int cont=1;
        while((linea=buffer.readLine())!=null){
            partes=linea.split(" ");
            suma+=Double.parseDouble(partes[1]);
            cont++;
        }
        return "Media= "+suma/cont;
    }
    
    public static void escribir(String fichero, String salida) throws IOException{
        FileWriter archivo=new FileWriter(salida);
        BufferedWriter buffer=new BufferedWriter(archivo);
        buffer.write(mayorNota(fichero));
        buffer.newLine();
        buffer.write(menorNota(fichero));
        buffer.newLine();
        buffer.write(media(fichero));
        buffer.close();
    }
    
    public static void main(String[] args) throws IOException {
        Scanner teclado=new Scanner(System.in);
        String entrada="C:\\Users\\Carlos\\Documents\\NetBeansProjects\\ExamenT78\\src\\main\\java\\com\\mycompany\\examen78\\buffers\\Notas.txt";
        String salida="C:\\Users\\Carlos\\Documents\\NetBeansProjects\\ExamenT78\\src\\main\\java\\com\\mycompany\\examen78\\buffers\\Resultados.txt";
        int op;
        do{
            menu();
            op=teclado.nextInt();
            switch(op){
                case 1:
                    verNotas(entrada);
                    break;
                case 2:
                    System.out.println(mayorNota(entrada));
                    break;
                case 3:
                    System.out.println(menorNota(entrada));
                    break;
                case 4:
                    System.out.println(media(entrada));
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Numero no contemplado");
            }
        }while(op!=5);
        escribir(entrada, salida);
    }
    
}
