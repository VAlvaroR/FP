/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exament78;

import java.time.*;
import java.util.*;

/**
 *
 * @author Carlos
 */
public class ExamenT78 {

    public static void menu(){
        System.out.println("ELIGE UNA OPCION:"
                + "\n1. Ver fechas\n"
                + "2. Añadir fecha\n"
                + "3. Salir");
    }
    public static void annadir(LinkedHashSet lista, Scanner teclado){
        int year, mes, dia;
        System.out.println("Dime el año: ");
        year=teclado.nextInt();
        System.out.println("Dime el mes: ");
        mes=teclado.nextInt();
        System.out.println("Dime el dia del mes: ");
        dia=teclado.nextInt();
        lista.add(LocalDate.of(year, mes, dia));
    }
    public static void mostrarLista(LinkedHashSet lista){
        System.out.println(lista.toString());
    }
    
    public static void main(String[] args) {
        LinkedHashSet <LocalDate> eclipses=new LinkedHashSet();
        Scanner teclado=new Scanner(System.in);
        int op;
        eclipses.add(LocalDate.of(2017, Month.AUGUST, 21));
        eclipses.add(LocalDate.of(2015, Month.MARCH, 20));
        eclipses.add(LocalDate.of(2021, Month.JUNE, 10));
        eclipses.add(LocalDate.of(2025, Month.MARCH, 29));
        eclipses.add(LocalDate.of(2024, Month.APRIL, 8));
        
        do{
            menu();
            op=teclado.nextInt();
            teclado.nextLine();
            switch(op){
                case 1:
                    mostrarLista(eclipses);
                    break;
                case 2:
                    annadir(eclipses,teclado);
                    break;
                case 3:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.err.println("Opcion no contemplada por el programa");
                    break;
            }
        }while(op!=3);
    }
}
