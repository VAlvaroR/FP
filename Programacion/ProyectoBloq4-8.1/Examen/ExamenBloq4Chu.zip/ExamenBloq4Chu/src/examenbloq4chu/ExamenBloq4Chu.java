/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examenbloq4chu;

import java.util.*;
import java.io.*;

public class ExamenBloq4Chu {

    public static void main(String[] args) {

        /*
         * ========================================================
         * 1. LIST
         * ========================================================
         *
         * Características:
         *   - Mantiene el orden de inserción
         *   - Permite elementos repetidos
         *   - Permite acceso por índice
         *
         * Usar cuando:
         *   - Importa el orden
         *   - Puede haber duplicados
         */

        // --------------------------------------------------------
        // ArrayList
        // --------------------------------------------------------
        /*
         * Lista general más usada.
         *
         * Usar cuando:
         *   - Necesitas acceso por índice
         *   - Añades elementos normalmente al final
         */
        List<String> arrayList = new ArrayList<>();
        arrayList.add("uno");
        arrayList.add("dos");

        // --------------------------------------------------------
        // LinkedList
        // --------------------------------------------------------
        /*
         * Lista útil cuando se insertan o eliminan muchos elementos.
         *
         * Usar cuando:
         *   - Modificas mucho la lista
         *   - Trabajas con inserciones o borrados frecuentes
         */
        List<String> linkedList = new LinkedList<>();
        linkedList.add("A");
        linkedList.add("B");

        // --------------------------------------------------------
        // Vector
        // --------------------------------------------------------
        /*
         * Clase antigua de listas.
         *
         * Usar cuando:
         *   - Te lo pidan en teoría
         *   - Veas código antiguo
         */
        List<String> vector = new Vector<>();
        vector.add("ejemplo");

        // --------------------------------------------------------
        // Stack
        // --------------------------------------------------------
        /*
         * Representa una pila (LIFO).
         *
         * Operaciones:
         *   push() -> meter
         *   pop()  -> sacar
         *
         * Hoy se suele sustituir por ArrayDeque.
         */
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);


        /*
         * ========================================================
         * 2. SET
         * ========================================================
         *
         * Características:
         *   - No permite elementos duplicados
         *   - No tiene índice
         *
         * Usar cuando:
         *   - No quieres elementos repetidos
         */

        // --------------------------------------------------------
        // HashSet
        // --------------------------------------------------------
        /*
         * Set más usado.
         *
         * Usar cuando:
         *   - Solo quieres elementos únicos
         *   - No importa el orden
         */
        Set<String> hashSet = new HashSet<>();
        hashSet.add("rojo");
        hashSet.add("azul");

        // --------------------------------------------------------
        // LinkedHashSet
        // --------------------------------------------------------
        /*
         * Set que mantiene el orden de inserción.
         *
         * Usar cuando:
         *   - No quieres duplicados
         *   - Quieres mantener el orden de inserción
         */
        Set<String> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add("primero");
        linkedHashSet.add("segundo");

        // --------------------------------------------------------
        // TreeSet
        // --------------------------------------------------------
        /*
         * Set que mantiene los elementos ordenados.
         *
         * Usar cuando:
         *   - Necesitas los elementos ordenados
         */
        Set<Integer> treeSet = new TreeSet<>();
        treeSet.add(5);
        treeSet.add(1);
        treeSet.add(3);


        /*
         * ========================================================
         * 3. QUEUE
         * ========================================================
         *
         * Representa una cola.
         *
         * Funciona normalmente FIFO:
         *   First In First Out
         *
         * Usar cuando:
         *   - Los elementos se procesan en orden de llegada
         */

        // --------------------------------------------------------
        // LinkedList como Queue
        // --------------------------------------------------------
        /*
         * Cola simple.
         *
         * Operaciones:
         *   offer() -> añadir
         *   poll()  -> sacar
         *   peek()  -> consultar primero
         */
        Queue<String> cola = new LinkedList<>();
        cola.offer("cliente1");
        cola.offer("cliente2");

        // --------------------------------------------------------
        // PriorityQueue
        // --------------------------------------------------------
        /*
         * Cola donde los elementos salen según prioridad.
         *
         * Usar cuando:
         *   - Necesitas procesar elementos por prioridad
         */
        Queue<Integer> priorityQueue = new PriorityQueue<>();
        priorityQueue.offer(30);
        priorityQueue.offer(10);
        priorityQueue.offer(20);


        /*
         * ========================================================
         * 4. DEQUE
         * ========================================================
         *
         * Cola de doble extremo.
         *
         * Permite añadir o quitar por ambos lados.
         *
         * Usar cuando:
         *   - Necesitas trabajar por los dos extremos
         *   - Quieres implementar pila o cola
         */

        // --------------------------------------------------------
        // ArrayDeque
        // --------------------------------------------------------
        /*
         * Implementación muy usada de Deque.
         *
         * Usar cuando:
         *   - Quieres una pila moderna
         *   - Quieres una cola rápida
         */
        Deque<String> deque = new ArrayDeque<>();

        // como cola
        deque.offerLast("uno");
        deque.offerLast("dos");

        // como pila
        deque.push("arriba1");
        deque.push("arriba2");


        /*
         * ========================================================
         * 5. MAP
         * ========================================================
         *
         * Guarda pares:
         *   clave -> valor
         *
         * Características:
         *   - No permite claves duplicadas
         *
         * Usar cuando:
         *   - Necesitas asociar una clave con un valor
         */

        // --------------------------------------------------------
        // HashMap
        // --------------------------------------------------------
        /*
         * Map más utilizado.
         *
         * Usar cuando:
         *   - No importa el orden
         */
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Ana", 20);
        hashMap.put("Luis", 25);

        // --------------------------------------------------------
        // LinkedHashMap
        // --------------------------------------------------------
        /*
         * Map que mantiene el orden de inserción.
         *
         * Usar cuando:
         *   - Quieres conservar el orden en que se añadieron
         */
        Map<String, String> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("es", "hola");
        linkedHashMap.put("en", "hello");

        // --------------------------------------------------------
        // TreeMap
        // --------------------------------------------------------
        /*
         * Map que mantiene las claves ordenadas.
         *
         * Usar cuando:
         *   - Necesitas un Map ordenado
         */
        Map<Integer, String> treeMap = new TreeMap<>();
        treeMap.put(3, "tres");
        treeMap.put(1, "uno");

        // --------------------------------------------------------
        // Hashtable
        // --------------------------------------------------------
        /*
         * Clase antigua similar a HashMap.
         *
         * Usar cuando:
         *   - Aparezca en teoría o código antiguo
         */
        Map<String, String> hashtable = new Hashtable<>();
        hashtable.put("clave", "valor");


        /*
         * ========================================================
         * RESUMEN RÁPIDO
         * ========================================================
         *
         * LIST
         *   ArrayList     -> Lista general
         *   LinkedList    -> Lista con muchas modificaciones
         *   Vector        -> Lista antigua
         *   Stack         -> Pila antigua
         *
         * SET
         *   HashSet       -> Sin duplicados, sin orden
         *   LinkedHashSet -> Sin duplicados, mantiene orden
         *   TreeSet       -> Sin duplicados, ordenado
         *
         * QUEUE / DEQUE
         *   LinkedList    -> Cola simple
         *   PriorityQueue -> Cola por prioridad
         *   ArrayDeque    -> Pila o cola moderna
         *
         * MAP
         *   HashMap       -> Clave-valor sin orden
         *   LinkedHashMap -> Clave-valor con orden
         *   TreeMap       -> Clave-valor ordenado
         *   Hashtable     -> Map antiguo
         *
         * ========================================================
         */
        
        
        // -----------------------------------------------------------------------------------------
        // -----------------------------------------------------------------------------------------
        // -----------------------------------------------------------------------------------------
        // -----------------------------------------------------------------------------------------
        
        /*
         * ========================================================
         * 1. FICHEROS DE TEXTO
         * ========================================================
         *
         * Se utilizan para trabajar con texto.
         *
         * Clases principales:
         *   FileReader
         *   FileWriter
         *   BufferedReader
         *   BufferedWriter
         *   Scanner
         */

        // --------------------------------------------------------
        // FileReader
        // --------------------------------------------------------
        /*
         * Permite leer un fichero de texto carácter a carácter.
         *
         * Método principal:
         *   read()
         *
         * El último carácter devuelve -1.
         */

        try {

            FileReader entrada = new FileReader("archivo.txt");

            int c = 0;

            while (c != -1) {

                c = entrada.read();

                char letra = (char) c;

                System.out.print(letra);

            }

            entrada.close();

        } catch (IOException e) {

            System.out.println("Error: " + e.getMessage());

        }


        // --------------------------------------------------------
        // FileWriter
        // --------------------------------------------------------
        /*
         * Permite escribir caracteres en un fichero de texto.
         *
         * Método principal:
         *   write()
         *
         * Si se usa true escribe al final del fichero.
         */

        try {

            FileWriter salida = new FileWriter("archivo.txt");

            String s = "frase de prueba";

            int i = 0;

            while (i < s.length()) {

                char c = s.charAt(i++);

                salida.write(c);

            }

            salida.close();

        } catch (IOException e) {

            System.out.println("Error");

        }


        /*
         * ========================================================
         * 2. LECTURA Y ESCRITURA CON BUFFER
         * ========================================================
         *
         * Se usa para trabajar más rápido con archivos grandes.
         *
         * Especialmente útil para leer líneas completas.
         */

        // --------------------------------------------------------
        // BufferedReader
        // --------------------------------------------------------
        /*
         * Permite leer líneas completas.
         *
         * Método principal:
         *   readLine()
         *
         * La última línea devuelve null.
         */

        try {

            FileReader entrada = new FileReader("archivo.txt");

            BufferedReader buf = new BufferedReader(entrada);

            String linea = "";

            while (linea != null) {

                linea = buf.readLine();

                if (linea != null) {

                    System.out.println(linea);

                }

            }

            buf.close();

        } catch (IOException e) {

            System.out.println("Error");

        }


        // --------------------------------------------------------
        // BufferedWriter
        // --------------------------------------------------------
        /*
         * Permite escribir texto de forma más eficiente.
         *
         * Se pueden escribir Strings completos.
         *
         * Para escribir una línea nueva:
         *   "\n"
         */

        try {

            BufferedWriter buf =
                    new BufferedWriter(new FileWriter("archivo.txt", true));

            int[] n = {3, 5, 6, 7, 8};

            for (int i = 0; i < n.length; i++) {

                String s = Integer.toString(n[i]) + "\n";

                buf.write(s);

            }

            buf.close();

        } catch (IOException e) {

            System.out.println("Error");

        }


        /*
         * ========================================================
         * 3. LECTURA CON SCANNER
         * ========================================================
         *
         * Permite leer datos de distintos tipos desde un fichero.
         *
         * Muy útil para leer números.
         *
         * Métodos comunes:
         *   hasNextInt()
         *   hasNextDouble()
         *   nextInt()
         *   nextDouble()
         *   nextLine()
         */

        try {

            Scanner lector = new Scanner(new FileReader("archivo.txt"));

            int cont = 0;

            double suma = 0.0;

            while (lector.hasNextDouble()) {

                double n = lector.nextDouble();

                System.out.println("Número: " + n);

                cont++;

                suma += n;

            }

            System.out.println("Media: " + suma / cont);

            lector.close();

        } catch (Exception e) {

            System.out.println("Error");

        }


        /*
         * ========================================================
         * 4. FICHEROS BINARIOS
         * ========================================================
         *
         * Se trabajan byte a byte.
         *
         * Clases:
         *   FileInputStream
         *   FileOutputStream
         */

        try {

            FileInputStream file1 = new FileInputStream("archivo.bin");

            int byteLeido;

            while ((byteLeido = file1.read()) != -1) {

                System.out.println(byteLeido);

            }

            file1.close();

        } catch (IOException e) {

            System.out.println("Error");

        }


        /*
         * ========================================================
         * 5. ESCRIBIR BYTES EN UN FICHERO
         * ========================================================
         */

        try {

            FileOutputStream file2 = new FileOutputStream("archivo2.bin");

            int[] datos = {10, 20, 30, 40};

            for (int i = 0; i < datos.length; i++) {

                file2.write(datos[i]);

            }

            file2.close();

        } catch (IOException e) {

            System.out.println("Error");

        }


        /*
         * ========================================================
         * 6. SERIALIZACIÓN DE OBJETOS
         * ========================================================
         *
         * Permite guardar objetos en un fichero.
         *
         * La clase debe implementar:
         *
         *   Serializable
         *
         * Clases usadas:
         *   ObjectOutputStream
         *   ObjectInputStream
         */


        // --------------------------------------------------------
        // Guardar objetos
        // --------------------------------------------------------

        try {

            ObjectOutputStream flujo1 =
                    new ObjectOutputStream(
                            new FileOutputStream("objetos.dat"));

            String ejemplo = "Objeto guardado";

            flujo1.writeObject(ejemplo);

            flujo1.close();

        } catch (IOException e) {

            System.out.println("Error");

        }


        // --------------------------------------------------------
        // Leer objetos
        // --------------------------------------------------------

        try {

            ObjectInputStream flujo2 =
                    new ObjectInputStream(
                            new FileInputStream("objetos.dat"));

            Object obj = flujo2.readObject();

            System.out.println(obj);

            flujo2.close();

        } catch (Exception e) {

            System.out.println("Error");

        }


        /*
         * ========================================================
         * RESUMEN RÁPIDO DE EXAMEN
         * ========================================================
         *
         * FICHEROS DE TEXTO
         *   FileReader  -> leer caracteres
         *   FileWriter  -> escribir caracteres
         *
         * CON BUFFER
         *   BufferedReader -> leer líneas
         *   BufferedWriter -> escribir texto
         *
         * LECTURA DE DATOS
         *   Scanner -> leer números, cadenas, líneas
         *
         * FICHEROS BINARIOS
         *   FileInputStream  -> leer bytes
         *   FileOutputStream -> escribir bytes
         *
         * OBJETOS
         *   ObjectOutputStream -> guardar objetos
         *   ObjectInputStream  -> leer objetos
         *
         * ========================================================
         */
    }
}
