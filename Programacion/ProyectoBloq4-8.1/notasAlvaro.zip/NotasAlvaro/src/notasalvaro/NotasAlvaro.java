/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package notasalvaro;

/**
 *
 * @author alvaror
 */
import java.util.*;
import java.io.*;

public class NotasAlvaro {
    static final String fichero = "/home/alvaror/Escritorio/notas.dat";
    
    static Scanner sc = new Scanner(System.in);
    static Map<String, Map<String, Double>> notas = new LinkedHashMap<>();

    public static void main(String[] args) {

        cargarDatos();
        
        int resp;

        do {
            System.out.println("=================================");
            System.out.println("         GESTOR DE NOTAS         ");
            System.out.println("=================================");
            System.out.println("1) Ver notas alumno");
            System.out.println("2) Ver notas modulo");
            System.out.println("3) Poner notas modulo");
            System.out.println("4) Quitar alumno");
            System.out.println("5) Añadir alumno");
            System.out.println("6) Quitar modulo");
            System.out.println("7) Añadir modulo");
            System.out.println("8) Ver todo");
            System.out.println("9) Salir");
            System.out.print("Opcion: ");
            System.out.println();

            resp = leerEntero();
            
            switch (resp) {
                case 1:
                    verNotasAlumno();
                    break;
                case 2:
                    verNotasModulo();
                    break;
                case 3:
                    ponerNotasModulo();
                    guardarDatos();
                    break;
                case 4:
                    quitarAlumno();
                    guardarDatos();
                    break;
                case 5:
                    anadirAlumno();
                    guardarDatos();
                    break;
                case 6:
                    quitarModulo();
                    guardarDatos();
                    break;
                case 7:
                    anadirModulo();
                    guardarDatos();
                    break;
                case 8:
                    verTodo();
                    break;
                case 9:
                    guardarDatos();
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion no valida.");
                    break;
            }

            if (resp != 9) {
                System.out.println("\nENTER para continuar...");
                sc.nextLine();
            }

        } while (resp != 9);
    }

    // ---------------- OPCIONES MENU ----------------

    // 1) Ver notas alumno
    static void verNotasAlumno() {
        List<String> alumnos = listaAlumnos();
        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos.");
            return;
        }

        mostrarLista("ALUMNOS", alumnos);
        int idx = elegir(alumnos.size(), "Elige alumno (nº): ");
        if (idx == -1) return;

        String alumno = alumnos.get(idx);
        List<String> modulos = listaModulos();

        if (modulos.isEmpty()) {
            System.out.println("No hay modulos.");
            return;
        }

        System.out.println("\nAlumno: " + alumno);

        double suma = 0;
        int cuenta = 0;

        for (String m : modulos) {
            Double n = notas.get(alumno).get(m); // puede ser null
            System.out.printf("  - %-20s : %s%n", m, (n == null ? "-" : formatear(n)));

            if (n != null) {
                suma += n;
                cuenta++;
            }
        }

        if (cuenta == 0) System.out.println("Media: -");
        else System.out.println("Media: " + formatear(suma / cuenta));
    }

    // 2) Ver notas módulo
    static void verNotasModulo() {
        List<String> modulos = listaModulos();
        if (modulos.isEmpty()) {
            System.out.println("No hay modulos.");
            return;
        }

        mostrarLista("MODULOS", modulos);
        int idx = elegir(modulos.size(), "Elige modulo (nº): ");
        if (idx == -1) return;

        String modulo = modulos.get(idx);
        List<String> alumnos = listaAlumnos();

        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos.");
            return;
        }

        System.out.println("\nModulo: " + modulo);

        double suma = 0;
        int cuenta = 0;

        for (String a : alumnos) {
            Double n = notas.get(a).get(modulo);
            System.out.printf("  - %-20s : %s%n", a, (n == null ? "-" : formatear(n)));

            if (n != null) {
                suma += n;
                cuenta++;
            }
        }

        if (cuenta == 0) System.out.println("Media del modulo: -");
        else System.out.println("Media del modulo: " + formatear(suma / cuenta));
    }

    // 3) Poner notas módulo
    static void ponerNotasModulo() {
        List<String> modulos = listaModulos();
        if (modulos.isEmpty()) {
            System.out.println("No hay modulos.");
            return;
        }

        mostrarLista("MODULOS", modulos);
        int idx = elegir(modulos.size(), "Elige modulo (nº): ");
        if (idx == -1) return;

        String modulo = modulos.get(idx);
        List<String> alumnos = listaAlumnos();

        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos.");
            return;
        }

        System.out.println("\nEditando notas de: " + modulo);
        System.out.println("ENTER = mantener nota");
        System.out.println("Escribe un numero para cambiarla (ej: 7.5)\n");

        for (String a : alumnos) {
            Double actual = notas.get(a).get(modulo);
            System.out.print(a + " (actual: " + (actual == null ? "-" : formatear(actual)) + ") nueva: ");

            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue; // mantener

            Double nueva = leerDouble(line);
            if (nueva == null) {
                System.out.println("  Número invalido, se mantiene.");
            } else {
                notas.get(a).put(modulo, nueva);
            }
        }

        System.out.println("\nNotas actualizadas.");
    }

    // 4) Quitar alumno
    static void quitarAlumno() {
        List<String> alumnos = listaAlumnos();
        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos.");
            return;
        }

        mostrarLista("ALUMNOS", alumnos);
        int idx = elegir(alumnos.size(), "Elige alumno a eliminar (nº): ");
        if (idx == -1) return;

        String alumno = alumnos.get(idx);
        notas.remove(alumno);
        System.out.println("Alumno eliminado: " + alumno);
    }

    // 5) Añadir alumno
    static void anadirAlumno() {
        List<String> alumnos = listaAlumnos();
        mostrarLista("ALUMNOS", alumnos);

        System.out.print("Nombre del nuevo alumno: ");
        String nombre = sc.nextLine().trim();

        if (nombre.isEmpty()) {
            System.out.println("Nombre vacio.");
            return;
        }
        if (notas.containsKey(nombre)) {
            System.out.println("Ese alumno ya existe.");
            return;
        }

        // crear su mapa de módulos con null
        Map<String, Double> mapaModulos = new LinkedHashMap<>();
        for (String m : listaModulos()) mapaModulos.put(m, null);

        notas.put(nombre, mapaModulos);
        System.out.println("Alumno añadido: " + nombre);
    }

    // 6) Quitar módulo
    static void quitarModulo() {
        List<String> modulos = listaModulos();
        if (modulos.isEmpty()) {
            System.out.println("No hay modulos.");
            return;
        }

        mostrarLista("MODULOS", modulos);
        int idx = elegir(modulos.size(), "Elige modulo a eliminar (nº): ");
        if (idx == -1) return;

        String modulo = modulos.get(idx);

        // eliminar ese módulo en todos los alumnos
        for (String a : notas.keySet()) {
            notas.get(a).remove(modulo);
        }

        System.out.println("Modulo eliminado: " + modulo);
    }

    // 7) Añadir módulo
    static void anadirModulo() {
        List<String> modulos = listaModulos();
        mostrarLista("MODULOS", modulos);

        System.out.print("Nombre del nuevo modulo: ");
        String modulo = sc.nextLine().trim();

        if (modulo.isEmpty()) {
            System.out.println("Nombre vacio.");
            return;
        }
        if (modulos.contains(modulo)) {
            System.out.println("Ese modulo ya existe.");
            return;
        }

        // añadir módulo a todos los alumnos con null
        for (String a : notas.keySet()) {
            notas.get(a).put(modulo, null);
        }

        System.out.println("Modulo añadido: " + modulo);
    }

    // 8) Ver todo
    static void verTodo() {
        List<String> alumnos = listaAlumnos();
        List<String> modulos = listaModulos();

        if (alumnos.isEmpty()) {
            System.out.println("No hay alumnos.");
            return;
        }
        if (modulos.isEmpty()) {
            System.out.println("No hay modulos.");
            return;
        }

        // Cabecera
        System.out.printf("%-15s", "ALUMNO");
        for (String m : modulos) System.out.printf(" | %-10s", recortar(m, 10));
        System.out.println();

        // Línea
        System.out.println("-".repeat(15 + (modulos.size() * 13)));

        // Filas
        for (String a : alumnos) {
            System.out.printf("%-15s", recortar(a, 15));
            for (String m : modulos) {
                Double n = notas.get(a).get(m);
                System.out.printf(" | %-10s", (n == null ? "-" : formatear(n)));
            }
            System.out.println();
        }
    }

    // ---------------- FUNCIONES SECUNDARIAS ----------------

    static List<String> listaAlumnos() {
        return new ArrayList<>(notas.keySet());
    }

    static List<String> listaModulos() {
        // Sacamos módulos mirando al primer alumno (simple)
        if (notas.isEmpty()) return new ArrayList<>();
        String primero = notas.keySet().iterator().next();
        return new ArrayList<>(notas.get(primero).keySet());
    }

    static void mostrarLista(String titulo, List<String> lista) {
        System.out.println("\n--- " + titulo + " ---");
        if (lista.isEmpty()) {
            System.out.println("(vacio)");
            return;
        }
        for (int i = 0; i < lista.size(); i++) {
            System.out.println((i + 1) + ") " + lista.get(i));
        }
        System.out.println();
    }

    static int elegir(int max, String mensaje) {
        System.out.print(mensaje);
        int n = leerEntero();
        if (n < 1 || n > max) {
            System.out.println("Fuera de rango.");
            return -1;
        }
        return n - 1;
    }

    static int leerEntero() {
        while (true) {
            String s = sc.nextLine().trim();
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.print("Introduce un entero valido: ");
            }
        }
    }

    static Double leerDouble(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static String formatear(double x) {
        return String.format(Locale.US, "%.2f", x);
    }

    static String recortar(String s, int max) {
        if (s.length() <= max) return s;
        return s.substring(0, max - 1) + "…";
    }
    
    static void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero))) {
            oos.writeObject(notas);
        } catch (IOException e) {
            System.out.println("Error al guardar los datos.");
        }
    }
    
    static void cargarDatos() {
        File f = new File(fichero);

        if (!f.exists()) {
            notas = new LinkedHashMap<>();
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fichero))) {
            notas = (Map<String, Map<String, Double>>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar los datos.");
            notas = new LinkedHashMap<>();
        }
    }
}
